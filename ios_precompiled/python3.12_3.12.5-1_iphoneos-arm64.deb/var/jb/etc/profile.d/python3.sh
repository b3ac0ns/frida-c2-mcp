export PATH="/var/jb/usr/local/bin:$PATH"
